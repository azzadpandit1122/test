package com.azzadpandit.azadproject.Model;

public class LoginModel {
    String email,password;

    public LoginModel(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
